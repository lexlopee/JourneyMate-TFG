package com.example.JourneyMate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JourneyMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
